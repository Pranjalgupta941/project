import React from 'react'

export default function Photo( ram) {
  return (
    <div>
        <img src={ram.url}/>
    </div>
  )
}