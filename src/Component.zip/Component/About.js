import React from 'react'
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";
export default function About() {
  return (
    <div>
      <p>About pranjal</p>
      </div>
  )
}
