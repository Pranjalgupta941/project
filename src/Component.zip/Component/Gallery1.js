import React from 'react'

export  function Gallery1() {
  return (
    <div>
        <img src ="img/Snap.jpg"/>
    </div>
  )
}


