import React from 'react'

export default function Second() {
  return (
    <>
      <img src="img/Snap.jpg"/>
    </>
  );
}
