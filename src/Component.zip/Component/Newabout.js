import React from 'react'

export default function Newabout() {
  return (
    <div>
        <p>
            hello world
        </p>
    </div>
  )
}
