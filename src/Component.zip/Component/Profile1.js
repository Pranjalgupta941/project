import React from 'react'

export  function Profile1() {
  return (
    <div>
    <p> this iddhncd sdkjdcoknc cnjkjcioaskl mncsajck</p>
    </div>
  )
}
